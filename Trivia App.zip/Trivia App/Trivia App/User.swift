//
//  User.swift
//  Trivia App
//
//  Created by Vinay Raj K on 24/01/20.
//  Copyright © 2020 Vinay Raj K. All rights reserved.
//

import Foundation

class User: NSObject {
    @objc var name: String?
    @objc var favCricketer: String?
    @objc var colors: String?
}
